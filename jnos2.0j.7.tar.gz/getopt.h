extern int  optind;
extern char *optarg;
  
int getopt(int, char **, char *);
