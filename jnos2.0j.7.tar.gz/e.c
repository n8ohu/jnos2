
#include "global.h"
main ()
{
	printf ("%d\n", sizeof(int));
	printf ("%d\n", sizeof(int16));
	printf ("%d\n", sizeof(int32));
}
